/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cryptography2;

/**
 *
 * @author LATITUDE 7480
 */
class vigenere {
    
    
     String table = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
     
       public String Cleaning_text(String text)
     {
         text = text.replaceAll(" ", "");  
         
////        for(int x = 0; x < text.length(); x++)
////        {
////            int position = table.indexOf(text.charAt(x));
////             
////        }        
        return text;
    }  
        
  public  String Encrypt(String text,String key)
{
  text=text.toUpperCase();
  key=key.toUpperCase();
//  String cleaned_text = Cleaning_text(text);
  String encrypted = "";
 
  for(int t = 0,k= 0; t < text.length(); t++,k= (k+1) % key.length())
  {
    int position = (table.indexOf(text.charAt(t)) + table.indexOf(key.charAt(k))) % table.length();

   encrypted += table.charAt(position );

  }
    return encrypted;
}  
        
public String Decrypt(String text,String key  )
{
     text=text.toUpperCase();
    key=key.toUpperCase();
//  String cleaned_text = Cleaning_text(text);  
    
  String decrypted = "";

  for(int t = 0, k = 0; t < text.length(); t++,k= (k+1) % key .length())
  {
   int position = (table.indexOf(text.charAt(t)) - table.indexOf(key.charAt(k)));

   position = (position < 0)?(position + table.length()): position;

   decrypted += table.charAt(position);
   }
   return decrypted;
}        
 
        
    }
    
 
