/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cryptography2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author LATITUDE 7480
 */
public class Cryptography2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
  
        vigenere v=new vigenere();
        String str, reponse = "";

        String directory = System.getProperty("user.home");
        String fileName = "a.txt";
        String fileName1 = "b.txt";
        String absolutePath = directory + File.separator + fileName;
        String absolutePath1 = directory + File.separator + fileName1;
        //--------------------
        System.out.print("1. Encryption\n2. Decryption\nChoose(1,2): ");
        Scanner in = new Scanner(System.in);
        int choice = in.nextInt();

        switch (choice) {
            case 1:

                System.out.println("Encryption");
                in.nextLine();
                BufferedReader ligne = new BufferedReader(new FileReader(absolutePath));

                System.out.print("Enter le clé : ");  
                String cle = in.nextLine();
                System.out.println(" la phrase à coder");
                str = ligne.readLine();
                System.out.println(str);
                
                
                System.out.println("Encryption  :" + v.Encrypt(str, cle));
                 reponse=v.Encrypt(str,cle);
                try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(absolutePath1))) {
                    String fileContent = reponse;
                    bufferedWriter.write(reponse);
                } catch (IOException e) {
                    // Exception handling
                }
                
                   break;
            case 2:

                System.out.println("Decryption");
                in.nextLine();
                BufferedReader br = new BufferedReader(new FileReader(absolutePath1));
                System.out.print("Enter le clé : ");  
                 String cle1 = in.nextLine();
                System.out.println("la phrase à décoder");
                str = br.readLine();
                System.out.println(str);
                System.out.println("decryption  :" + v.Decrypt(str, cle1));
                 reponse=v.Decrypt(str, cle1);
                 try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(absolutePath))) {
                 String fileContent = reponse;
                  bufferedWriter.write( reponse);
                } catch (IOException e) {
                    // Exception handling
                }
        
        
       
        
        
        
        
        
        
    } }
    
}
